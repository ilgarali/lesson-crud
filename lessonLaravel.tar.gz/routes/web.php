<?php

use App\Http\Controllers\Frontend\CategoryController;
use App\Http\Controllers\Frontend\HomeController;
use Illuminate\Support\Facades\Route;


Route::get('/', [HomeController::class, 'index']);
Route::post('/store', [CategoryController::class, 'store'])->name('storeCategory');
Route::get('/edit/{id}', [CategoryController::class, 'edit'])->name('editCategory');
Route::put('/udpate/{id}',[CategoryController::class,'update'])->name('updateCategory');;
